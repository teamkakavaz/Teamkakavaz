let bag=[];
function add(name,price){bag.push({name,price});render();document.getElementById('cart').classList.add('open');document.getElementById('shade').classList.add('show')}
function removeItem(i){bag.splice(i,1);render()}
function render(){document.getElementById('count').textContent=bag.length;document.getElementById('total').textContent='PKR '+bag.reduce((s,x)=>s+x.price,0).toLocaleString();document.getElementById('items').innerHTML=bag.length?bag.map((x,i)=>`<div class="cart-item"><span>${x.name}</span><strong>PKR ${x.price.toLocaleString()} <button onclick="removeItem(${i})" style="border:0;background:none;cursor:pointer">×</button></strong></div>`).join(''):'<p>Your bag is empty.</p>'}
function toggleCart(){document.getElementById('cart').classList.toggle('open');document.getElementById('shade').classList.toggle('show')}
function checkout(){if(!bag.length)return alert('Your bag is empty.');alert('Demo checkout: connect this button to your payment/order system when you are ready!')}
function join(e){e.preventDefault();document.getElementById('message').textContent='You’re on the list 🔥';e.target.reset()}
render();